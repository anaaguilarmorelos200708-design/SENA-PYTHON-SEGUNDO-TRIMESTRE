monto = float(input("Ingrese el monto del préstamo: "))

tasa_anual = 0.05   
plazo_anios = 5

interes_anual = monto * tasa_anual
interes_trimestre = interes_anual / 4  
interes_mes = interes_anual / 12        
interes_total = interes_anual * plazo_anios
total_pagar = monto + interes_total

print(f"\n--- RESULTADOS ---")
print(f"Interés pagado en un año: ${interes_anual:,.2f}")
print(f"Interés pagado en el tercer trimestre del año: ${interes_trimestre:,.2f}")
print(f"Interés pagado en el primer mes: ${interes_mes:,.2f}")
print(f"Total a pagar (monto + intereses): ${total_pagar:,.2f}")





