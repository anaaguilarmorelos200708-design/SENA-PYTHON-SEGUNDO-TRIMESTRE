IVA_TASA = 0.16  # 16% de IVA

monto_venta = float(input("Ingrese el monto de la venta: "))

iva = monto_venta * IVA_TASA
total_pagar = monto_venta + iva

print(f"IVA: ${iva:.2f}")
print(f"Total a pagar: ${total_pagar:.2f}")

pago = float(input("Ingrese la cantidad con la que paga el cliente: "))

cambio = pago - total_pagar

print(f"Cambio: ${cambio:.2f}")

