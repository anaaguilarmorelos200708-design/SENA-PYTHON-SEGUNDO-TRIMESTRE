metros = float(input("Cuantos metros vas a subir en la montaña?"))
hxm = (5/7)*60
print("Te demoras un estimado de ", ((hxm*metros)/60) , " horas en subir la montaña")
