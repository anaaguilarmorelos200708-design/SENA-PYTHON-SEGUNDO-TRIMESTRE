import random
numero = random.randint(3000,10000)
producto = str(input("Que producto deseas comprar?\n"))
precio = float(numero)
cantidad = int(input("Que cantidad deseas llevar? "))
print(f"Vas a llevar {cantidad} {producto} que tiene un sub total de {cantidad*precio} y con iva te quedaria {(cantidad*precio)+((cantidad*precio)*0.19)} ")
