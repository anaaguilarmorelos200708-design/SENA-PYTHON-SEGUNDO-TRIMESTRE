#Lea la cantidad de dinero correspondiente a una compra y calcule el valor del IVA (19%), 
#y el valor total de la factura, si al valor de la compra se le autoriza un descuento del 10% (antes de aplicarle el IVA).
cantidad = float(input("ingrese la cantidad de dinero de la compra: ",))
iva1 = cantidad*0.19
descuento = cantidad*0.10
iva2 = descuento*0.19
factura = cantidad+iva2-descuento
print ("la cantidad de dinero de la compra incluido iva es: ",iva1)
print ("el valor total de la factura es: ",factura)

