#Dada las horas trabajadas de una persona y el valor por hora. Calcular su salario e imprimirlo. 
horas = float(input("ingrese la cantidad de horas: ",))
valor = float(input("ingrese el valor por hora: ",))
salario = valor*horas
print ("su salario es: ",salario)