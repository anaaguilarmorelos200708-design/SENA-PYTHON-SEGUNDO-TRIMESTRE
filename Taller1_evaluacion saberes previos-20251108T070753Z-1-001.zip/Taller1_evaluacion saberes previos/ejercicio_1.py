#Lea tres números y calcule el resultado de su suma.
num1 = 3
num2 = 6
num3 = 8
suma = num1+num2+num3
print ("la suma de 3 numeros es: ", suma)