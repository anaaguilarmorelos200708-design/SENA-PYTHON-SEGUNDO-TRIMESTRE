# Lea dos números y calcule el resultado de su suma, resta, multiplicación y división.
num1 = 4
num2 = 8
suma = num1+num2
resta = num1-num2
multiplicacion = num1*num2
if num2 != 0: 
    division = num1/num2
else:
    division =  "no se puede didivir por cero"   
print ("el resultado de suma es : ", suma)
print ("el resultado de resta es : ", resta)
print ("el resultado de multiplicacion es : ", multiplicacion)
print ("el resultado de division es : ", division)
