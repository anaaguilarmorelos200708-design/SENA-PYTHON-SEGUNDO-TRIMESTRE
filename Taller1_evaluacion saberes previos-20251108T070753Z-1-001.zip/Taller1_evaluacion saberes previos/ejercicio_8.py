#Suponga que un individuo desea invertir su capital en un banco y desea saber
#cuánto dinero ganará después de un mes si el banco paga a razón de 2% mensual.
capital = float(input("ingrese el capital: "))
porcentaje = 0.02
dinerogan = capital*porcentaje
print ("el dinero ganado despues de un mes es: ",dinerogan)


	
