#Dadas las 3 notas de un aprendiz, calcule la definitiva de la asignatura.
nota1 = float(input("ingrese la primera nota: "))
nota2 = float(input("ingrese la segunda nota: "))
nota3 = float(input("ingrese la tercera nota: "))
definitiva = (nota1+nota2+nota3)/3
print ("la definitiva es: ", definitiva)