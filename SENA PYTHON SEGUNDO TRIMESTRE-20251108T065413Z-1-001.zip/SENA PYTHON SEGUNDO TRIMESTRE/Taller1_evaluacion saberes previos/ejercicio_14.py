arroz = 8000
leche = 6000
queso = 9500
huevo = 400
total = 0
total_unidades = 0

objeto = int(input("MARCA\n1. para arroz\n2. para leche\n3. para queso\n4. para huevo\n"))
while True:
     objeto=int(input(" "))
     if objeto==1:
         print(f"Arroz : {arroz}")
         total+=arroz
         total_unidades+=1
     elif objeto==2:
         print(f"Leche : {leche}")
         total+=leche
         total_unidades+=1
     elif objeto==3:
         print(f"Queso : {queso}")
         total+=queso
         total_unidades+=1
     elif objeto==4:
         print(f"Huevo : {huevo}")
         total+=huevo
         total_unidades+=1
     else:
       print("saliendo de la facturacion")

     break
print(f"El total a pagar con iva es: {total+(total*0.19)}\nTotal de unidades es: {total_unidades}")
