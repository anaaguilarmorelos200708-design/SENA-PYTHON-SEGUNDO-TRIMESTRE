#4.	Dadas las 3 notas de un aprendiz, calcule la definitiva de la asignatura si la primera nota tiene un valor del 20%, 
#la segunda del 30% y la última del 50%.
nota1 = float(input("ingresa la primera nota:"))
nota2 = float(input("ingresa la segunda nota:"))
nota3 = float(input("ingresa la tercera nota:"))
operacion = {"nota1": nota1*0.20, "nota2": nota2*0.30, "nota3": nota3*0.50}
definitiva = nota1*0.20 + nota2*0.30 + nota3*0.50
print ("la definitiva es: ",definitiva)