#7.	Dada una cantidad de tiempo medida en horas, minutos y segundos, diga a cuántos segundos equivale.
horas = float(input("ingrese las horas exactas del tiempo: ",))
minutos = float(input("ingrese los minutos exactos del tiempo: ",))
segundos = float(input("ingrese los segundos exactos del tiempo: ",))
operesultado= (horas*3600)+(minutos*60)+(segundos)
print ("los segundos equivalentes a todo el tiempo estipulado son: ",operesultado)
