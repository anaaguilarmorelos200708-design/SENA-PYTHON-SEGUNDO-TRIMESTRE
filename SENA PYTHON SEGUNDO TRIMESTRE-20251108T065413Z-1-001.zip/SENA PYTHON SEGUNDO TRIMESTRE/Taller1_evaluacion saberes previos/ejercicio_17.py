while True:
     salario = float(input("Cual es tu salario?"))
     ahorro = float(input("Que porcentaje deseas ahorrar"))
     ahorrobb = ahorro/100
     print(f"deberias ahorrar {salario*ahorrobb} mensual")
     pago_salud = salario*0.125
     print(f"Debes deducir en salud un {pago_salud}")
     pago_pension = salario*0.16
     print(f"Tu pago de la pension debe debe de ser {pago_pension}")
     print(f"El total a recibir es: {salario-pago_salud-pago_pension-(salario*ahorrobb)}")
     salir=int(input("Si desea salir marque .1"))
     if salir==1:
         break
