#Un maestro desea saber qué porcentaje de hombres y qué porcentaje de mujeres 
#hay en un grupo de alumnos.
hombres = float(input("ingrese la cantidad de alumnos: "))
mujeres = float(input("ingrese la cantidad de alumnas: "))
total =  hombres+mujeres
hporcentaje = (hombres/total)*100
mporcentaje= (mujeres/total)*100
print ("el porcentaje de hombres es: ",hporcentaje)
print ("el porcentaje de mujeres es: ",mporcentaje)
