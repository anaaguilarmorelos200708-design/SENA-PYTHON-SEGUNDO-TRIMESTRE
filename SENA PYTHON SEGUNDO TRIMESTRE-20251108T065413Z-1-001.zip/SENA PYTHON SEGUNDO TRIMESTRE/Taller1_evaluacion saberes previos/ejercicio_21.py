nombre_com = str(input("cual es tu nombre?\n"))
año = int(input("que año naciste?\n"))
direccion = str(input("Ingresa tu direccion...\n"))
print(f"___INFORMACION APRENDIZ___\nTu edad es {año-2025}.\nTu nombre es {nombre_com}\nTu direccion es {direccion}")