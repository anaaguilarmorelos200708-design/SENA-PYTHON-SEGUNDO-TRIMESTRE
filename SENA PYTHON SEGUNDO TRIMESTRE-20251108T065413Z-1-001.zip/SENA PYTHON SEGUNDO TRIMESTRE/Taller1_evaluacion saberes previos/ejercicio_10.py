#Una tienda ofrece un descuento del 15% sobre el total de la compra y un cliente desea saber
#cuánto deberá pagar finalmente por su compra.
valorcom = float(input("ingrese el valor total de la compra: "))
operacion = valorcom*0.15
resultado = valorcom-operacion
print ("el valor a pagar finalmente es: ",resultado)