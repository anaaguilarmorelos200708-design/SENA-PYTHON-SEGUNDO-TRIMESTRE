#9.	Un vendedor recibe un sueldo base más un 10% extra por comisión de sus ventas, el vendedor desea saber cuánto dinero obtendrá por
#concepto de comisiones por las tres ventas que realiza en el mes y el total que recibirá en el mes tomando en cuenta su sueldo base y comisiones.
sueldo = float(input("ingrese el sueldo base: "))
ventas = float(input("ingrese el valor total de las ventas: "))
comision = ventas*0.10
total = sueldo+comision
print ("el total que recibira en el mes es: ",total)


