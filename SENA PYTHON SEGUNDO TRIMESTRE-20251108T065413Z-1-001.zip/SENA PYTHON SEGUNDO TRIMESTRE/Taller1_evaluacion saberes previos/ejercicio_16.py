recaudado=float(input("Total recaudado...:"))
print(f"lo que te corresponde es: {recaudado*0.19} en total")
