#Lea la distancia (en kilómetros) recorrida por un auto,
#el tiempo (en horas) en que la recorrió y calcule la velocidad a la cual se desplazaba el auto (V=D/T).
distancia = float(input("ingrese la distancia recorrida en kilometros: "))
tiempo = float(input("ingrese el tiempo en horas: "))
velocidad = distancia/tiempo
print ("la velocidad es: ",velocidad)