tiempoxlitro = 1.5
baldes = [5,3,1]
tiempoDllenado=[]
for i in baldes:
    tiempoDllenado.append(i*tiempoxlitro)
print(tiempoDllenado)
