nota_parcial=[]
promedio1=0
for i in range(3):
     nota=float(input(f"Cual es tu nota #{i+1}: "))
     nota_parcial.append(nota)
for j in nota_parcial:
     promedio1=promedio1+j
     promedio1=promedio1/3
print(promedio1)
examen_f=float(input("Cuanto sacaste en el examen final"))
trabajo_final=float(input("Cuanto sacaste en el trabajo final"))
print(f"La calificacion final es {(promedio1*0.55)+(examen_f*0.30)+(trabajo_final*0.15)}")
